# repository.mhancoc7.public

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/c20f4922237541f7aa6c2395319652ed)](https://app.codacy.com/app/mhancoc7/repository.mhancoc7.public?utm_source=github.com&utm_medium=referral&utm_content=mhancoc7/repository.mhancoc7.public&utm_campaign=Badge_Grade_Dashboard)

## This is the git repo for the m7 repo

[Download Here](https://m7kodi.dev)

## Submit issues via m7 Kodi Addons

[m7_kodi_addons](https://m7kodi.dev)
