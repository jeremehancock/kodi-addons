'''
    Goat TV Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import Addon, source
import sys, os, urllib, urllib2
import json, base64
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')

stream_url = 'https://www.goatslive.com/iframe.php'
match_string = 'embed/(.+?)"'

Addon.plugin_url = sys.argv[0]
Addon.plugin_handle = int(sys.argv[1])
Addon.plugin_queries = Addon.parse_query(sys.argv[2][1:])

dlg = xbmcgui.Dialog()

Addon.log('plugin url: ' + Addon.plugin_url)
Addon.log('plugin queries: ' + str(Addon.plugin_queries))
Addon.log('plugin handle: ' + str(Addon.plugin_handle)) 

addon_logo = xbmc.translatePath(os.path.join(plugin_path,'tvaddons_logo.png'))

mode = Addon.plugin_queries['mode']

def play(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url

if mode == 'main':
    if Addon.get_setting('auto_start') == "true":
        xbmcgui.Dialog().notification(addon_name + ' is provided by:','www.tvaddons.co',addon_logo,10000,False)
        yt_addon = xbmcaddon.Addon('plugin.video.youtube')
        if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
            dlg.ok(addon_name, Addon.get_string(8002))
            yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
            xbmc.executebuiltin('yt_settings')
            xbmc.executebuiltin('Activatewindow(home)')
        else:
            req = urllib2.Request(stream_url)
            req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib2.urlopen(req)
            link = response.read()
            response.close()
            id = Addon.find_single_match(link,match_string)
            if id is not "":
                stream = play(id)
                xbmc.Player().play(stream)
                xbmc.executebuiltin('Activatewindow(home)')
            else:
                dlg.ok(addon_name, Addon.get_string(8003))
                xbmc.executebuiltin('Activatewindow(home)')
    else:
        Addon.addLink('Watch Live','','','goats_live',xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'browse_goats_youtube'}, 'GoatsLive Youtube Channel', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        if len(Addon.get_setting('notify')) > 0:
            Addon.set_setting('notify', str(int(Addon.get_setting('notify')) + 1))  
        else:
            Addon.set_setting('notify', "1")        
        if int(Addon.get_setting('notify')) == 1:
            xbmcgui.Dialog().notification(addon_name + ' is provided by:','www.tvaddons.co',addon_logo,5000,False)
        elif int(Addon.get_setting('notify')) == 9:
            Addon.set_setting('notify', "0")

def show_streams(title, playlist_id):
    if mode == title:
        streams = source.Source().get_streams(playlist_id)
        if streams:
            for c in streams:
                title = c['title']
                channel = c['title']
                videoId = c['videoId']
                img = c['img']
                rURL = Addon.plugin_url + "?channel=" + channel + "&videoId=" + videoId + "&mode=play"
                Addon.add_video_item(rURL, {'title': title}, img=img)

    elif mode == 'play':
        videoId = Addon.plugin_queries['videoId']
        stream_status = source.Source()._get_json('/check' + base64.b64decode('LnBocA=='), {'id': videoId})['status']
        if stream_status == 'true':
            stream_url = play(videoId)
            item = xbmcgui.ListItem(path=stream_url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        else:
            dlg.ok(Addon.get_string(5000), Addon.get_string(7000))
            exit()

def goats_live(url):
    yt_addon = xbmcaddon.Addon('plugin.video.youtube')
    if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
        dlg.ok(addon_name, Addon.get_string(8002))
        yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
        xbmc.executebuiltin('yt_settings')
    else:
        req = urllib2.Request(url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        id = Addon.find_single_match(link,match_string)
        if id is not "":
            stream = play(id)
            item = xbmcgui.ListItem(path=stream)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        else:
            dlg.ok(addon_name, Addon.get_string(8003))

if mode == 'browse_goats_youtube':
    try:
        playlists = source.Source().build_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title']}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(8000))
        exit()

if mode != 'main' or mode != 'goats_live' or mode != 'browse_goats_youtube':
    playlists = source.Source().build_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

if mode == 'goats_live':
    goats_live(stream_url)

if mode == 'refresh':
    xbmc.executebuiltin('Container.Refresh')

def get_params():
                param=[]
                paramstring=sys.argv[2]
                if len(paramstring)>=2:
                                params=sys.argv[2]
                                cleanedparams=params.replace('?','')
                                if (params[len(params)-1]=='/'):
                                    params=params[0:len(params)-2]
                                pairsofparams=cleanedparams.split('&')
                                param={}
                                for i in range(len(pairsofparams)):
                                    splitparams={}
                                    splitparams=pairsofparams[i].split('=')
                                    if (len(splitparams))==2:
                                        param[splitparams[0]]=splitparams[1]
                                                                
                return param
                                            
params=get_params()
url = None
mode = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass

Addon.end_of_directory()
