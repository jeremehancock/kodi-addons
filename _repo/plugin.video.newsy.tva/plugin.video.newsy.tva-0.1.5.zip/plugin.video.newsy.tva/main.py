'''
    Newsy Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import Addon, source
import sys, os, urllib, urllib2
import json, base64
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addonid = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addonid).getAddonInfo('path')

Addon.plugin_url = sys.argv[0]
Addon.plugin_handle = int(sys.argv[1])
Addon.plugin_queries = Addon.parse_query(sys.argv[2][1:])

dlg = xbmcgui.Dialog()

Addon.log('plugin url: ' + Addon.plugin_url)
Addon.log('plugin queries: ' + str(Addon.plugin_queries))
Addon.log('plugin handle: ' + str(Addon.plugin_handle)) 

addon_logo = xbmc.translatePath(os.path.join(plugin_path,'tvaddons_logo.png'))

mode = Addon.plugin_queries['mode']

def get_youtube_stream(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url

if mode == 'main':
    if Addon.get_setting('auto_start') == "true":
        req = urllib2.Request('http://www.newsy.com/live/')
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()

        url = "http:" + Addon.find_single_match(link,'<div class="live-player"><script src="(.*?)"')

        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()

        stream = Addon.find_single_match(link,'"file": "(.*?)"')

        if stream is not "":
            li = xbmcgui.ListItem (Addon.get_string(5000))
            xbmc.Player().play(stream, li, False)
            xbmc.executebuiltin('Activatewindow(home)')
        else:
            dlg.ok(Addon.get_string(5000), Addon.get_string(8000))
            xbmc.executebuiltin('Activatewindow(home)')
    else:
        Addon.addLink('Watch Live','','','newsy_live',xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_business'}, 'Business', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_entertainment'}, 'Entertainment', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_headlines'}, 'Headlines', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_politics'}, 'Politics', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_scihealth'}, 'Science/Health', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_sports'}, 'Sports', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_tech'}, 'Tech', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_usnews'}, 'US News', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'newsy_world'}, 'World News', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))
        Addon.add_directory({'mode': 'browse_newsy_youtube'}, 'Newsy YouTube Channel', img = xbmc.translatePath(os.path.join(plugin_path,'icon.png')))

def show_streams(title, playlist_id):
    if mode == title:
        streams = source.Source().get_streams(playlist_id)
        if streams:
            for c in streams:
                title = c['title']
                channel = c['title']
                videoId = c['videoId']
                img = c['img']
                rURL = Addon.plugin_url + "?channel=" + channel + "&videoId=" + videoId + "&mode=play"
                Addon.add_video_item(rURL, {'title': title}, img=img)

    elif mode == 'play':
        videoId = Addon.plugin_queries['videoId']
        stream_status = source.Source()._get_json('/check' + base64.b64decode('LnBocA=='), {'id': videoId})['status']
        if stream_status == 'true':
            stream_url = get_youtube_stream(videoId)
            item = xbmcgui.ListItem(path=stream_url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        else:
            dlg.ok(Addon.get_string(5000), Addon.get_string(7000))
            exit()

def newsy_live(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = "http:" + Addon.find_single_match(link,'<div class="live-player"><script src="(.*?)"')

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    stream = Addon.find_single_match(link,'"file": "(.*?)"')
    
    Addon.play(stream)

def newsy_website(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    matches = Addon.find_multiple_matches(link,'<div class="hero-module-1">(.*?)</p>')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'<h2 class="title">(.+?)</h2>').replace("&amp;", "&").replace("&#039;", "'")
        description = ""
        url = "https://www.newsy.com" + Addon.find_single_match(entry,'<a class="link" href="(.+?)"')
        iconimage = Addon.find_single_match(entry,'<img class="image image-cover" src="(.+?)"')
        if "http" in url:
            Addon.addLink(name,description,url,1,iconimage)

    link = Addon.find_single_match(link,'<div class="content-box">(.+?)<ul class="pagination">')
    matches = Addon.find_multiple_matches(link,'<a (.*?)3>')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'<h3 class="title">(.+?)</h').replace("&amp;", "&").replace("&#039;", "'")
        description = ""
        url = "https://www.newsy.com" + Addon.find_single_match(entry,'href="(.+?)"')
        iconimage = Addon.find_single_match(entry,'data-lazyload="(.+?)"')
        if "http" in url:
            Addon.addLink(name,description,url,1,iconimage)

def newsy_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'file&quot;:&quot;(.*?)&quot;')
    
    Addon.play(url)

if mode == 'browse_newsy_youtube':
    try:
        playlists = source.Source().build_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title']}, c['title'], img = c['img'])
        if len(Addon.get_setting('notify')) > 0:
            Addon.set_setting('notify', str(int(Addon.get_setting('notify')) + 1))  
        else:
            Addon.set_setting('notify', "1")        
        if int(Addon.get_setting('notify')) == 1:
            xbmcgui.Dialog().notification(addonname + ' is provided by:','www.tvaddons.co',addon_logo,5000,False)
        elif int(Addon.get_setting('notify')) == 9:
            Addon.set_setting('notify', "0")
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(8000))
        exit()

if mode != 'main' or mode != 'newsy_live' or mode != 'browse_newsy_youtube':
    playlists = source.Source().build_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

if mode == 'newsy_live':
    newsy_live('http://www.newsy.com/live/')

if mode == 'newsy_usnews':
    newsy_website('https://www.newsy.com/categories/us/')

if mode == 'newsy_politics':
    newsy_website('https://www.newsy.com/categories/politics/')

if mode == 'newsy_world':
    newsy_website('https://www.newsy.com/categories/world/')

if mode == 'newsy_scihealth':
    newsy_website('https://www.newsy.com/categories/sci-health/')

if mode == 'newsy_tech':
    newsy_website('https://www.newsy.com/categories/tech/')

if mode == 'newsy_entertainment':
    newsy_website('https://www.newsy.com/categories/entertainment/')

if mode == 'newsy_sports':
    newsy_website('https://www.newsy.com/categories/sports/')

if mode == 'newsy_business':
    newsy_website('https://www.newsy.com/categories/business/')

if mode == 'newsy_headlines':
    newsy_website('https://www.newsy.com/sections/headlines/')

if mode == 'refresh':
    xbmc.executebuiltin('Container.Refresh')

def get_params():
                param=[]
                paramstring=sys.argv[2]
                if len(paramstring)>=2:
                                params=sys.argv[2]
                                cleanedparams=params.replace('?','')
                                if (params[len(params)-1]=='/'):
                                    params=params[0:len(params)-2]
                                pairsofparams=cleanedparams.split('&')
                                param={}
                                for i in range(len(pairsofparams)):
                                    splitparams={}
                                    splitparams=pairsofparams[i].split('=')
                                    if (len(splitparams))==2:
                                        param[splitparams[0]]=splitparams[1]
                                                                
                return param
                                            
params=get_params()
url = None
mode = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass

if mode == 1:
    newsy_stream(url)

Addon.end_of_directory()
