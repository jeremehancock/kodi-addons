"""
    m7lib

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Checkout the Free Live TV addon for an example of how to use m7lib
    https://github.com/mhancoc7/kodi-addons/tree/master/_repo/plugin.video.freelivetv.tva
"""

import os
import json
import base64
import re
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import sys
import string
import random

try:
    # Python 2
    from urllib2 import urlopen, Request
except ImportError:
    # Python 3
    from urllib.request import urlopen, Request

try:
    # Python 2
    from HTMLParser import HTMLParser
except ImportError:
    # Python 3
    from html.parser import HTMLParser

convert_special_characters = HTMLParser()
dlg = xbmcgui.Dialog()

yt_addon = xbmcaddon.Addon('plugin.video.youtube')
youtube_message = "This channel requires MPEG-DASH to be enabled in the YouTube addon. Once enabled try again."
stream_failed = "Unable to get stream. Please try again later."
stream_plug = "aHR0cHM6Ly90dnRpbWUudmVsdmV0aG90ZG9nLmNvbS9saXZldHZfZGlyZWN0L3YxL2dldF9zdHJlYW0ucGhwP2lkPQ=="
stirr_base = "aHR0cHM6Ly9vdHQtZ2F0ZXdheS1zdGlyci5zaW5jbGFpcnN0b3J5bGluZS5jb20vYXBpL3Jlc3QvdjMvc3RhdHVzLw=="
pluto_base = "aHR0cDovL2FwaS5wbHV0by50di92Mi9jaGFubmVscz9hcHBOYW1lPXdlYiZkZXZpY2VNYWtlPUNocm9tZSZkZXZpY2VUeXBlPXdlYiY="

class Common:

    @staticmethod
    def dlg_failed(mode):
        dlg.ok(mode, stream_failed)
        exit()

    @staticmethod
    def random_generator(size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for x in range(size))

    @staticmethod
    def youtube_settings(channel):
        dlg.ok(channel, youtube_message)
        yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
        xbmc.executebuiltin(str(yt_settings))

    @staticmethod
    # Parse string and extracts first match as a string
    # The default is to find the first match. Pass a 'number' if you want to match a specific match. So 1 would match
    # the second and so forth
    def find_single_match(text, pattern, number=0):
        try:
            matches = re.findall(pattern, text, flags=re.DOTALL)
            result = matches[number]
        except:
            result = ""
        return result

    @staticmethod
    # Parse string and extracts multiple matches using regular expressions
    def find_multiple_matches(text, pattern):
        matches = re.findall(pattern, text, re.DOTALL)
        return matches

    @staticmethod
    # Open URL
    def open_url(url, user_agent=True):
        req = Request(url)
        if user_agent != False:
            req.add_header('User-Agent',
                           'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11'
                           '(KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
        response = urlopen(req)
        link = response.read()
        response.close()
        return link

    @staticmethod
    # Section, Genre, or Channel logos
    def get_logo(channel, type=None):
        if type is None:
            return xbmc.translatePath(
                os.path.join('special://home/addons/script.module.m7lib', 'lib', 'resources', 'images',
                             channel + ".png"))
        elif type == "section":
            return xbmc.translatePath(
                os.path.join('special://home/addons/script.module.m7lib', 'lib', 'resources', 'images', 'sections',
                             channel + ".png"))
        elif type == "genre":
            return xbmc.translatePath(
                os.path.join('special://home/addons/script.module.m7lib', 'lib', 'resources', 'images', 'genres',
                             channel + ".png"))

    @staticmethod
    # Available channels
    def get_channels():
        channel_list = [
                            {"name": "24-7 Retro", "type": "Retro"},
                            {"name": "Action Movies", "type": "Movies, Action"},
                            {"name": "Aljazeera", "type": "News"},
                            {"name": "Big Life TV", "type": "Lifestyle"},
                            {"name": "Bloomberg", "type": "News"},
                            {"name": "Buzzr", "type": "Retro"},
                            {"name": "Catholic TV Network", "type": "Faith"},
                            {"name": "Celebrity Page Network", "type": "Celebrity"},
                            {"name": "Charge!", "type": "Action"},
                            {"name": "Cheddar", "type": "News"},
                            {"name": "Classic Movies Channel", "type": "Movies, Retro"},
                            {"name": "Classic Toons TV", "type": "Retro, Kids"},
                            {"name": "Classic TV", "type": "Retro"},
                            {"name": "CNBC", "type": "News"},
                            {"name": "Cold Case Files", "type": "Crime, 24-7"},
                            {"name": "Comet", "type": "Sci-Fi"},
                            {"name": "CONtv", "type": "Special Interest"},
                            {"name": "Crime Network", "type": "Crime"},
                            {"name": "Dove", "type": "Faith"},
                            {"name": "Dust", "type": "Sci-Fi"},
                            {"name": "Evine", "type": "Shopping"},
                            {"name": "Fail Army", "type": "Special Interest"},
                            {"name": "Flashback TV", "type": "Retro"},
                            {"name": "Fight", "type": "Sports"},
                            {"name": "Flicks of Fury", "type": "Movies, Action"},
                            {"name": "Forensic Files", "type": "Crime, 24-7"},
                            {"name": "FOX Sports", "type": "Sports"},
                            {"name": "Futurism", "type": "Curiosity, Special Interest"},
                            {"name": "GLORY Kickboxing", "type": "Sports"},
                            {"name": "Gravitas Movies", "type": "Movies"},
                            {"name": "Gusto", "type": "Lifestyle"},
                            {"name": "HSN", "type": "Shopping"},
                            {"name": "Hunt Channel", "type": "Special Interest"},
                            {"name": "IMPACT Wrestling", "type": "Sports"},
                            {"name": "Jewelry TV", "type": "Shopping"},
                            {"name": "Light TV", "type": "Faith"},
                            {"name": "Mobcrush", "type": "Special Interest"},
                            {"name": "Movie Mix", "type": "Movies"},
                            {"name": "NASA TV", "type": "Curiosity"},
                            {"name": "NBC News", "type": "News"},
                            {"name": "Newsmax", "type": "News"},
                            {"name": "Outdoor America", "type": "Lifestyle"},
                            {"name": "PBS Kids", "type": "Kids"},
                            {"name": "Pluto TV Biography", "type": "Biography, Curiosity"},
                            {"name": "Pluto TV Comedy", "type": "Movies, Comedy"},
                            {"name": "Pluto TV Conspiracy", "type": "Curiosity"},
                            {"name": "Pluto TV Documentaries", "type": "Documentary, Curiosity"},
                            {"name": "Pluto TV Drama", "type": "Movies"},
                            {"name": "Pluto TV Family", "type": "Movies, Family"},
                            {"name": "Pluto TV Movies", "type": "Movies"},
                            {"name": "Pluto TV Movies 2", "type": "Movies"},
                            {"name": "Pluto TV Romance", "type": "Movies, Romance"},
                            {"name": "Pluto TV Sitcoms", "type": "Comedy"},
                            {"name": "Pluto TV Thrillers", "type": "Movies, Thriller"},
                            {"name": "Pluto TV Westerns", "type": "Movies, Western"},
                            {"name": "QVC", "type": "Shopping"},
                            {"name": "RadioU", "type": "Music"},
                            {"name": "Rev'n TV", "type": "Special Interest"},
                            {"name": "RT News", "type": "News"},
                            {"name": "Runway TV", "type": "Lifestyle"},
                            {"name": "Sky News", "type": "News"},
                            {"name": "Soar", "type": "Special Interest"},
                            {"name": "Spirit TV", "type": "Faith"},
                            {"name": "Stadium", "type": "Sports"},
                            {"name": "Stirr Life", "type": "Lifestyle"},
                            {"name": "Stirr Movies", "type": "Movies"},
                            {"name": "Stirr Sports", "type": "Sports"},
                            {"name": "TBD", "type": "Special Interest"},
                            {"name": "Tennis Channel", "type": "Sports"},
                            {"name": "The Asylum", "type": "Movies, Sci-Fi"},
                            {"name": "The Country Network", "type": "Music"},
                            {"name": "The New Detectives", "type": "Crime, 24-7"},
                            {"name": "The Pet Collective", "type": "Special Interest"},
                            {"name": "Unsolved Mysteries", "type": "Crime, 24-7"},
                            {"name": "World Poker Tour", "type": "Special Interest"}
                        ]

        return channel_list

    @staticmethod
    # Available sections
    def get_sections():
        section_list = ["All Channels", "Genres"]
        return section_list

    @staticmethod
    # Available genres
    def get_genres():
        genre_list = ["24-7", "Action", "Biography", "Celebrity", "Comedy", "Crime", "Curiosity", "Documentary",
                      "Faith", "Family", "Kids", "Lifestyle", "News", "Movies", "Music", "Retro", "Romance", "Sci-Fi",
                      "Shopping", "Special Interest", "Sports", "Thriller", "Western"]
        return genre_list

    @staticmethod
    def add_channel(mode, icon, fanart, title=None, live=True):
        if live is False:
            u = sys.argv[0] + "?mode=" + str(mode)
        else:
            u = sys.argv[0] + "?mode=" + str(mode) + "&rand=" + Common.random_generator()
        ok = True
        if title is not None:
            item = title
        else:
            item = mode
        liz = xbmcgui.ListItem(str(item), iconImage="DefaultFolder.png", thumbnailImage=icon)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable", "true")
        liz.setInfo('video', {'Title': item})
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
        return ok

    @staticmethod
    def add_section(mode, icon, fanart, title=None):
        u = sys.argv[0] + "?mode=" + str(mode) + "&rand=" + Common.random_generator()
        ok = True
        if title is not None:
            item = title
        else:
            item = mode
        liz = xbmcgui.ListItem(str(item), iconImage="DefaultFolder.png", thumbnailImage=icon)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable", "true")
        liz.setInfo('video', {'Title': item})
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
        return ok

    @staticmethod
    # Return the Channel ID from YouTube URL
    def get_youtube_channel_id(url):
        return url.split("?v=")[-1].split("/")[-1].split("?")[0].split("&")[0]

    @staticmethod
    # Return the full YouTube plugin url
    def get_playable_youtube_url(channel_id):
        return 'plugin://plugin.video.youtube/play/?video_id=%s' % channel_id

    @staticmethod
    # Add rebase=on to stream URL
    def rebase(stream):
        rebase = 'rebase=on'
        if '?' in stream:
            return stream + '&' + rebase
        return stream + '?' + rebase

    @staticmethod
    # Play stream
    # Optional: set xbmc_player to True to use xbmc.Player() instead of xbmcplugin.setResolvedUrl()
    def play(stream, channel=None, xbmc_player=False):
        if xbmc_player:
            li = xbmcgui.ListItem(channel)
            xbmc.Player().play(stream, li, False)
        else:
            item = xbmcgui.ListItem(channel, path=stream)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

    @staticmethod
    # Get and Play stream
    def get_stream_and_play(mode):
        if mode == "24-7 Retro":
            stream = Stream.twenty_four_seven_retro()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Action Movies":
            stream = Stream.action_movies()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Aljazeera":
            stream = Stream.aljazeera()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Big Life TV":
            stream = Stream.big_life_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Bloomberg":
            stream = Stream.bloomberg()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Buzzr":
            stream = Stream.buzzr()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Catholic TV Network":
            stream = Stream.catholic_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Celebrity Page Network":
            stream = Stream.celebrity_page_network()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Charge!":
            stream = Stream.charge()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Cheddar":
            stream = Stream.cheddar()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Classic Movies Channel":
            stream = Stream.classic_movies_channel()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Classic Toons TV":
            stream = Stream.classic_toons_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Classic TV":
            stream = Stream.classic_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "CNBC":
            stream = Stream.cnbc()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Cold Case Files":
            stream = Stream.cold_case_files()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Comet":
            stream = Stream.comet()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "CONtv":
            stream = Stream.contv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Crime Network":
            stream = Stream.crime_network()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Dove":
            stream = Stream.dove()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Dust":
            stream = Stream.dust()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Evine":
            stream = Stream.evine()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Fail Army":
            stream = Stream.fail_army()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Fight":
            stream = Stream.fight()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Flashback TV":
            stream = Stream.flashback_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Flicks of Fury":
            stream = Stream.flicks_of_fury()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Forensic Files":
            stream = Stream.forensic_files()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "FOX Sports":
            stream = Stream.fox_sports()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Futurism":
            stream = Stream.futurism()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "GLORY Kickboxing":
            stream = Stream.glory_kickboxing()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Gravitas Movies":
            stream = Stream.gravitas_movies()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Gusto":
            stream = Stream.gusto()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "HSN":
            stream = Stream.hsn()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Hunt Channel":
            stream = Stream.hunt_channel()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "IMPACT Wrestling":
            stream = Stream.impact_wrestling()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)


        elif mode == "Jewelry TV":
            stream = Stream.jewelry_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Light TV":
            stream = Stream.light_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Mobcrush":
            stream = Stream.mobcrush()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Movie Mix":
            stream = Stream.movie_mix()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "NASA TV":
            stream = Stream.nasa_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "NBC News":
            stream = Stream.nbc_news()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Newsmax":
            stream = Stream.newsmax_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Outdoor America":
            stream = Stream.outdoor_america()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "PBS Kids":
            stream = Stream.pbs_kids()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Biography":
            stream = Stream.pluto_tv_biography()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Comedy":
            stream = Stream.pluto_tv_comedy()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Conspiracy":
            stream = Stream.pluto_tv_conspiracy()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Documentaries":
            stream = Stream.pluto_tv_documentaries()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Drama":
            stream = Stream.pluto_tv_drama()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Family":
            stream = Stream.pluto_tv_family()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Movies":
            stream = Stream.pluto_tv_movies()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Movies 2":
            stream = Stream.pluto_tv_movies_2()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Romance":
            stream = Stream.pluto_tv_romance()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Sitcoms":
            stream = Stream.pluto_tv_sitcoms()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Thrillers":
            stream = Stream.pluto_tv_thrillers()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Pluto TV Westerns":
            stream = Stream.pluto_tv_westerns()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "QVC":
            stream = Stream.qvc()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "RadioU":
            stream = Stream.campfire(mode)
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Rev'n TV":
            stream = Stream.revn_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "RT News":
            stream = Stream.rt()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Runway TV":
            stream = Stream.runway_tv()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Sky News":
            stream = Stream.sky_news()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Soar":
            stream = Stream.soar()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Spirit TV":
            stream = Stream.campfire(mode)
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Stadium":
            stream = Stream.stadium()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Stirr Life":
            stream = Stream.stirr_life()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Stirr Movies":
            stream = Stream.stirr_movies()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Stirr Sports":
            stream = Stream.stirr_sports()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "TBD":
            stream = Stream.tbd()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Tennis Channel":
            stream = Stream.tennis_channel()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "The Asylum":
            stream = Stream.the_asylum()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "The Country Network":
            stream = Stream.the_country_network()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "The New Detectives":
            stream = Stream.the_new_detectives()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "Unsolved Mysteries":
            stream = Stream.unsolved_mysteries()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "The Pet Collective":
            stream = Stream.the_pet_collective()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)

        elif mode == "World Poker Tour":
            stream = Stream.world_poker_tour()
            if stream is not None:
                Common.play(stream)
            else:
                Common.dlg_failed(mode)


class Stream:

    @staticmethod
    def twenty_four_seven_retro():
        try:
            site_url = "http://www.247retro.com/"
            match_string = 'src: "(.+?)"'
            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def action_movies():
        return Stream.pluto("Action Movies")

    @staticmethod
    def aljazeera():
        channel = 'Aljazeera'
        try:
            site_url = "https://www.aljazeera.com/live/"
            channel_match_string = '<iframe width="100%" src="(.+?)\&'
            video_match_string = '\'VIDEO_ID\': "(.+?)"'

            # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                Common.youtube_settings(channel)
            else:
                # Get A Jazerra YouTube Channel
                req = Common.open_url(site_url)
                channel_url = Common.find_single_match(req, channel_match_string)

                # Get Stream
                req = Common.open_url(channel_url)
                channel_id = Common.find_single_match(req, video_match_string)
                if channel_id is not "":
                    return Common.get_playable_youtube_url(channel_id)
                else:
                    return None
        except StandardError:
            return None

    @staticmethod
    def big_life_tv():
        return Stream.stirr("externallinearfeed-03-06-2019-235515534-03-06-2019")

    @staticmethod
    def bloomberg():
        try:
            req = Common.open_url(
                base64.b64decode(stream_plug) + 'bloomberg')
            bloomberg_json = json.loads(req)
            stream = bloomberg_json["results"][0]["stream"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            elif "youtube" in stream:
                channel_id = Common.get_youtube_channel_id(stream)
                return Common.get_playable_youtube_url(channel_id)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def buzzr():
        return Stream.stirr("buzzr-wurl-external")

    @staticmethod
    def catholic_tv():
        try:
            site_url = "http://www.catholictv.org/watch-live"
            player_match_string = '<iframe src="(.*?)"'
            stream_match_string = 'tp:releaseUrl="(.*?)\?'

            # Get Player
            req = Common.open_url(site_url)
            url = Common.find_single_match(req, player_match_string)

            # Get Stream
            req = Common.open_url(url)
            stream = Common.find_single_match(req, stream_match_string) + "?formats=m3u"

            if stream is not "":
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def celebrity_page_network():
        try:
            req = Common.open_url(
                base64.b64decode(stream_plug) + 'celebrity_page_network')
            celebrity_page_json = json.loads(req)
            stream = celebrity_page_json["results"][0]["stream"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            elif "youtube" in stream:
                channel_id = Common.get_youtube_channel_id(stream)
                return Common.get_playable_youtube_url(channel_id)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def charge():
        return Stream.stirr("charge")

    @staticmethod
    def cheddar():
        return Stream.stirr("cheddar-wurl-external")

    @staticmethod
    def classic_movies_channel():
        return Stream.pluto("Classic Movies Channel")

    @staticmethod
    def classic_toons_tv():
        return Stream.pluto("Classic Toons TV")

    @staticmethod
    def classic_tv():
        return Stream.pluto("Classic TV")

    @staticmethod
    def cnbc():
        return Stream.pluto("CNBC")

    @staticmethod
    def cold_case_files():
        return Stream.pluto("Cold Case Files")

    @staticmethod
    def comet():
        return Stream.stirr("comet-02-15-2018")

    @staticmethod
    def contv():
        return Stream.stirr("contv-wurl-external")

    @staticmethod
    def crime_network():
        return Stream.pluto("Crime Network")

    @staticmethod
    def dove():
        return Stream.stirr("dove-wurl-external")

    @staticmethod
    def dust():
        return Stream.stirr("dust-wurl-external")

    @staticmethod
    def evine():
        try:
            site_url = "https://www.evine.com/onair/watchuslive/"
            stream_match_string = "hlsStream: '(.+?)'"

            # Get stream url
            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, stream_match_string)

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def fail_army():
        return Stream.stirr("fail-army-wurl-external")

    @staticmethod
    def fight():
        return Stream.pluto("Fight")

    @staticmethod
    def flashback_tv():
        try:
            site_url = "https://flash1tv.com/"
            json_path_match_string = "//iframe.dacast.com(.+?)&quot;"

            # Get stream json path
            req = Common.open_url(site_url)
            json_path = Common.find_single_match(req, json_path_match_string)

            # Get stream
            json_url = "https://json.dacast.com" + json_path
            req = Common.open_url(json_url)
            stream_json = json.loads(req)
            stream = stream_json["hls"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def flicks_of_fury():
        return Stream.pluto("Flicks of Fury")

    @staticmethod
    def forensic_files():
        return Stream.pluto("Forensic Files")

    @staticmethod
    def fox_sports():
        return Stream.pluto("FOX Sports")

    @staticmethod
    def futurism():
        return Stream.stirr("futurism-wurl-external")

    @staticmethod
    def glory_kickboxing():
        return Stream.pluto("GLORY Kickboxing")

    @staticmethod
    def gravitas_movies():
        return Stream.stirr("gravitas-wurl-external")

    @staticmethod
    def gusto():
        return Stream.stirr("externallinearfeed-03-08-2019-021739216-03-08-2019")

    @staticmethod
    def hsn():
        channel = 'HSN'
        channel_url = ""
        try:
            hsn1_url = "https://www.hsn.com/watch/live"
            hsn2_url = "https://www.hsn.com/watch/live?network=4"
            stream_id_match_string = "watchTemplate.PlayLiveYoutubeVideo\('(.+?)'"
            program_match_string = '<span class="show-title" id="show-title" tabindex="0">(.+?)</span>'

            # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                Common.youtube_settings(channel)
            else:
                # Get HSN TV current program info
                req = Common.open_url(hsn1_url)
                hsn1_program = Common.find_single_match(req, program_match_string).replace("&amp;", "&")

                # Get HSN2 TV current program info
                req = Common.open_url(hsn2_url)
                hsn2_program = Common.find_single_match(req, program_match_string).replace("&amp;", "&")

                # Channel Selection
                source = xbmcgui.Dialog().select("Choose Channel", [
                    "[COLOR lightskyblue]HSN TV:[/COLOR] " + convert_special_characters.unescape(hsn1_program),
                    "[COLOR lightskyblue]HSN2 TV:[/COLOR] " + convert_special_characters.unescape(hsn2_program)
                ])
                if source == 0:
                    channel_url = hsn1_url
                elif source == 1:
                    channel_url = hsn2_url
                else:
                    exit()

                # Get HSN TV or HSN2 TV stream depending on Channel Selection
                req = Common.open_url(channel_url)
                channel_id = Common.find_single_match(req, stream_id_match_string)
                if channel_id is not "":
                    return Common.get_playable_youtube_url(channel_id)
                else:
                    return None
        except StandardError:
            return None

    @staticmethod
    def hunt_channel():
        try:
            site_url = "http://www.huntchannel.tv/"
            embed_match_string = '<script src="(.+?)"'
            stream_match_string = "container.offsetHeight, '(.+?)'"

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get stream url
            req = Common.open_url(embed_url)
            stream = Common.find_single_match(req, stream_match_string)

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def impact_wrestling():
        return Stream.pluto("IMPACT Wrestling")

    @staticmethod
    def jewelry_tv():
        try:
            site_url = "https://www.jtv.com/show/jtv-live/"
            embed_match_string = '<script src="(.+?)"'
            playlist_match_string = '"playlist": "(.+?)"'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get playlist
            req = Common.open_url(embed_url)
            playlist_url = "https:" + Common.find_single_match(req, playlist_match_string)

            # Get stream url
            req = Common.open_url(playlist_url)
            jewelry_tv_json = json.loads(req)
            stream = jewelry_tv_json["playlist"][0]["sources"][0]["file"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def light_tv():
        try:
            site_url = "http://www.lighttv.com/"
            embed_match_string = 'frameborder="0" scrolling="no" src="(.+?)"'
            tokens_match_string = 'tokens=(.+?)"'
            stream_match_string = 'src: "(.+?)"'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get tokens
            req = Common.open_url(site_url)
            tokens = Common.find_single_match(req, tokens_match_string)

            # Get stream url
            req = Common.open_url(embed_url)
            stream = Common.find_single_match(req, stream_match_string) + tokens

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def mobcrush():
        return Stream.stirr("mobcrush-wurl-external")

    @staticmethod
    def movie_mix():
        return Stream.stirr("movie-mix-wurl-external")

    @staticmethod
    def nasa_tv():
        try:
            # Channel Selection
            source = xbmcgui.Dialog().select("Choose Channel", [
                "[COLOR lightskyblue]NASA TV's Media Channel[/COLOR]",
                "[COLOR lightskyblue]Earth Views from the Space Station[/COLOR]",
                "[COLOR lightskyblue]NASA X[/COLOR]",
            ])

            if source == 0:
                # Get NASA TV Media Channel Stream
                req = Common.open_url(
                    base64.b64decode(stream_plug) + 'nasa_tv')
                nasa_tv_json = json.loads(req)
                stream = nasa_tv_json["results"][0]["stream"]

            elif source == 1:
                # Get NASA TV Space Station Channel Stream
                req = Common.open_url(
                    base64.b64decode(stream_plug) + 'nasa_tv_2')
                nasa_tv_2_json = json.loads(req)
                stream = nasa_tv_2_json["results"][0]["stream"]

            elif source == 2:
                # Get NASA X Stream
                stream = Stream.stirr("nasatv-gracenote-external")
            else:
                exit()

            # Play NASA TV stream depending on Channel Selection
            if "m3u8" in stream:
                return Common.rebase(stream)
            elif "youtube" in stream:
                channel_id = Common.get_youtube_channel_id(stream)
                return Common.get_playable_youtube_url(channel_id)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def nbc_news():
        return Stream.pluto("NBC News")

    @staticmethod
    def newsmax_tv():
        try:
            site_url = "https://www.newsmaxtv.com/"
            embed_match_string = '"embedUrl": "(.+?)"'
            stream_match_string = 'hlsStreamUrl(.+?)",'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get stream url
            req = Common.open_url(embed_url)
            stream = Common.find_single_match(req, stream_match_string)\
                .replace('\\":\\"', '')\
                .replace('\\\\\\', '')\
                .replace('\\', '')

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def outdoor_america():
        return Stream.stirr("outdoor-america-wurl-external")

    @staticmethod
    def pbs_kids():
        try:
            json_url = "http://pbskids.org/api/video/v1/livestream"

            # Get stream url
            req = Common.open_url(json_url)
            pbs_kids_json = json.loads(req)
            stream = pbs_kids_json["livestream"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def pluto_tv_biography():
        return Stream.pluto("Pluto TV Biography")

    @staticmethod
    def pluto_tv_comedy():
        return Stream.pluto("Pluto TV Comedy")

    @staticmethod
    def pluto_tv_conspiracy():
        return Stream.pluto("Pluto TV Conspiracy")

    @staticmethod
    def pluto_tv_documentaries():
        return Stream.pluto("Pluto TV Documentaries")

    @staticmethod
    def pluto_tv_drama():
        return Stream.pluto("Pluto TV Drama")

    @staticmethod
    def pluto_tv_family():
        return Stream.pluto("Pluto TV Family")

    @staticmethod
    def pluto_tv_movies():
        return Stream.pluto("Pluto TV Movies")

    @staticmethod
    def pluto_tv_movies_2():
        return Stream.pluto("Pluto TV Movies 2")

    @staticmethod
    def pluto_tv_romance():
        return Stream.pluto("Pluto TV Romance")

    @staticmethod
    def pluto_tv_sitcoms():
        return Stream.pluto("Pluto TV Sitcoms")

    @staticmethod
    def pluto_tv_thrillers():
        return Stream.pluto("Pluto TV Thrillers")

    @staticmethod
    def pluto_tv_westerns():
        return Stream.pluto("Pluto TV Westerns")

    @staticmethod
    def qvc():
        channel_url = ""
        try:
            site_url = "https://www.qvc.com/content/shop-live-tv.html"
            json_match_string = "var oLiveStreams=(.+?),\n"

            # Get QVC json
            # For some reason setting User Agent breaks things for QVC
            # Send False for user_agent
            req = Common.open_url(site_url, False)
            qvc_json = json.loads(Common.find_single_match(req, json_match_string))

            qvc_url = qvc_json["QVC"]["url"]
            qvc2_url = qvc_json["2CH"]["url"]
            iq_url = qvc_json["STA"]["url"]

            # Channel Selection
            source = xbmcgui.Dialog().select("Choose Channel", [
                "[COLOR lightskyblue]QVC[/COLOR]",
                "[COLOR lightskyblue]QVC2[/COLOR]",
                "[COLOR lightskyblue]Beauty IQ[/COLOR]"
            ])
            if source == 0:
                channel_url = qvc_url
            elif source == 1:
                channel_url = qvc2_url
            elif source == 2:
                channel_url = iq_url
            else:
                exit()

            # Play QVC stream depending on Channel Selection
            stream = "http:" + channel_url
            if "m3u8" in channel_url:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def radiou():
        return Stream.campfire("RadioU")

    @staticmethod
    def revn_tv():
        try:
            site_url = "http://www.revntv.com/watch/watch-online/"
            embed_match_string = '<iframe src="(.+?)"'
            tokens_match_string = '<script id="(.+?)"'
            json_url_main = 'http://json.dacast.com/b/'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = "http:" + Common.find_single_match(req, embed_match_string)

            # Get tokens
            req = Common.open_url(embed_url)
            tokens = Common.find_single_match(req, tokens_match_string).replace("_", "/")

            # Build json url
            json_url = json_url_main + tokens

            # Get stream url
            req = Common.open_url(json_url)
            revn_json = json.loads(req)
            stream = revn_json["hls"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def rt():
        channel_url = ""
        match_string = ""
        try:
            rt_url = "https://www.rt.com/on-air/"
            rtus_url = "https://www.rt.com/on-air/rt-america-air/"
            rtuk_url = "https://www.rt.com/on-air/rt-uk-air/"
            rtfr_url = "https://francais.rt.com/en-direct"
            rtar_url = "https://arabic.rt.com/live/"
            rtesp_url = "https://actualidad.rt.com/en_vivo"
            rtdoc_url = "https://rtd.rt.com/on-air/"
            stream_id_match_string = "file: '(.+?)'"
            stream_france_id_match_string = 'file: "(.+?)"'
            stream_arabic_id_match_string = "file': '(.+?)'"
            stream_spanish_id_match_string = "embed/(.+?)\?"
            stream_doc_id_match_string = 'url: "(.+?)"'

            # Channel Selection
            source = xbmcgui.Dialog().select("Choose Channel", [
                "[COLOR lightskyblue]RT Global[/COLOR]",
                "[COLOR lightskyblue]RT America[/COLOR]",
                "[COLOR lightskyblue]RT UK[/COLOR]",
                "[COLOR lightskyblue]RT France[/COLOR]",
                "[COLOR lightskyblue]RT Arabic[/COLOR]",
                "[COLOR lightskyblue]RT Spanish[/COLOR]",
                "[COLOR lightskyblue]RT Documentary[/COLOR]"
            ])
            if source == 0:
                channel_url = rt_url
                match_string = stream_id_match_string
            elif source == 1:
                channel_url = rtus_url
                match_string = stream_id_match_string
            elif source == 2:
                channel_url = rtuk_url
                match_string = stream_id_match_string
            elif source == 3:
                channel_url = rtfr_url
                match_string = stream_france_id_match_string
            elif source == 4:
                channel_url = rtar_url
                match_string = stream_arabic_id_match_string
            elif source == 5:
                channel_name = "RT Spanish"

                # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
                if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                    Common.youtube_settings(channel_name)
                    exit()
                else:
                    channel_url = rtesp_url
                    match_string = stream_spanish_id_match_string
            elif source == 6:
                channel_url = rtdoc_url
                match_string = stream_doc_id_match_string
            else:
                exit()

            # Get RT stream depending on Channel Selection
            req = Common.open_url(channel_url)

            # Use YouTube for RT Spanish Streams
            if source == 5:
                channel_id = Common.find_single_match(req, match_string)
                if channel_id is not "":
                    return Common.get_playable_youtube_url(channel_id)
                else:
                    return None

            # Stream direct for streams other than RT Spanish
            else:
                stream = Common.find_single_match(req, match_string)
                if "m3u8" in stream:
                    return Common.rebase(stream)
                else:
                    return None
        except StandardError:
            return None

    @staticmethod
    def soar():
        return Stream.stirr("soar-internal")

    @staticmethod
    def runway_tv():
        try:
            site_url = "http://www.runwaytv.com/"
            embed_match_string = '<iframe src="(.+?)"'
            stream_match_string = "source: '(.+?)'"

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get stream url
            req = Common.open_url(embed_url)
            stream = Common.find_single_match(req, stream_match_string)

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def sky_news():
        channel = 'Sky News'
        try:
            site_url = "https://news.sky.com/watch-live"
            match_string = 'embed/(.+?)\?'

            # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                Common.youtube_settings(channel)
            else:
                req = Common.open_url(site_url)
                channel_id = Common.find_single_match(req, match_string)
                if channel_id is not "":
                    return Common.get_playable_youtube_url(channel_id)
                else:
                    return None
        except StandardError:
            return None

    @staticmethod
    def spirittv():
        return Stream.campfire("Spirit TV")

    @staticmethod
    def stadium():
        try:
            site_url = "http://reachtv.com/live/WATCHSTADIUM"
            stream_match_string = 'var getPlayFile = "(.+?)"'

            # Get Stadium Stream
            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, stream_match_string)

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def stirr_life():
        return Stream.stirr("stirr-life-09-10-2018")

    @staticmethod
    def stirr_movies():
        return Stream.stirr("stirr-movies-wurl-external")

    @staticmethod
    def stirr_sports():
        return Stream.stirr("stirr-sports-09-10-2018")

    @staticmethod
    def tbd():
        return Stream.stirr("tbd-02-15-2018")

    @staticmethod
    def tennis_channel():
        return Stream.stirr("free")

    @staticmethod
    def the_asylum():
        return Stream.pluto("The Asylum")

    @staticmethod
    def the_country_network():
        try:
            site_url = "http://tcncountry.net/watch-live.htm"
            embed_match_string = '<iframe src="(.+?)"'
            tokens_match_string = '<script id="(.+?)"'
            json_url_main = 'http://json.dacast.com/b/'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get tokens
            req = Common.open_url(embed_url)
            tokens = Common.find_single_match(req, tokens_match_string).replace("_", "/")

            # Build json url
            json_url = json_url_main + tokens

            # Get stream url
            req = Common.open_url(json_url)
            tcn_json = json.loads(req)
            stream = tcn_json["hls"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def the_new_detectives():
        return Stream.pluto("The New Detectives")

    @staticmethod
    def unsolved_mysteries():
        return Stream.pluto("Unsolved Mysteries")

    @staticmethod
    def the_pet_collective():
        return Stream.stirr("the-pet-collective-wurl-external")

    @staticmethod
    def world_poker_tour():
        return Stream.stirr("world-poker-tour-wurl-external")

    @staticmethod
    def campfire(channel):
        channel_id = ""
        try:
            if channel == 'RadioU':
                channel_id = 'XDc'
            elif channel == 'Spirit TV':
                channel_id = 'bqg'

            site_url = "http://player.campfyre.tv/{id}".format(id=channel_id)
            match_string = 'file: "(.+?)"'

            req = Common.open_url(site_url)
            stream = "http:" + Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def stirr(url_slug):
        try:
            json_url = base64.b64decode(stirr_base) + url_slug

            # Get stream url
            req = Common.open_url(json_url)
            stirr_json = json.loads(req)
            stream = stirr_json["rss"]["channel"]["item"]["media:content"]["url"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def pluto(channel):
        try:
            json_url = base64.b64decode(pluto_base) + \
                       "sid=" + Common.random_generator(18, string.ascii_letters + string.digits) + \
                       "&deviceId=" + Common.random_generator(18, string.ascii_letters + string.digits)

            # Get stream url
            req = Common.open_url(json_url)
            pluto_json = json.loads(req)
            for i in pluto_json:
                if i["name"] == channel:
                    stream = i["stitched"]["urls"][0]["url"]
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None