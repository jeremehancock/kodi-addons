"""
    m7lib

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
import base64
import re
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import sys
import urllib2

dlg = xbmcgui.Dialog()

youtube_message = "This addon requires MPEG-DASH to be enabled in the YouTube addon. Once enabled try again."
report_stream = "aHR0cHM6Ly9taGFuY29jNy5zb3VyY2Vjb2RlLmFnL2xpdmV0dl9kaXJlY3QvdjEvcmVwb3J0X3N0cmVhbS5waHA/Y2hhbm5lbD0="

# Parse string and extracts multiple matches using regular expressions
def find_multiple_matches(text, pattern):
    matches = re.findall(pattern, text, re.DOTALL)
    return matches


def clean_hex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x":
            return unichr(int(text[3:-1], 16)).encode('utf-8')
        else:
            return unichr(int(text[2:-1])).encode('utf-8')

    try:
        return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:
        return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))


# Parse string and extracts first match as a string
def find_single_match(text, pattern):
    result = ""
    try:
        matches = re.findall(pattern, text, flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""

    return result


def play(url):
    resolved = url + '|User-Agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'
    item = xbmcgui.ListItem(path=resolved)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def play_youtube(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_playable_url(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url


def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
    response = urllib2.urlopen(req)
    link = response.read()
    link = clean_hex(link)
    response.close()
    return link


class Stream():

    @staticmethod
    def twenty_four_seven_retro():
        try:
            site_url = "http://www.247retro.com/"
            match_string = 'src: "(.+?)"'
            req = open_url(site_url)
            stream = find_single_match(req, match_string)
            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + '24-7_Retro')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + '24-7_Retro')
            return None

    @staticmethod
    def aljazeera():
        try:
            site_url = "https://www.aljazeera.com/live/"
            channel_match_string = '<iframe width="100%" src="(.+?)\&'
            video_match_string = '\'VIDEO_ID\': "(.+?)"'

            # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
            yt_addon = xbmcaddon.Addon('plugin.video.youtube')
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                dlg.ok('Aljazeera', youtube_message)
                yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
                xbmc.executebuiltin("yt_settings")
            else:
                # Get A Jazerra YouTube Channel
                req = open_url(site_url)
                channel_url = find_single_match(req, channel_match_string)

                # Get Stream
                req = open_url(channel_url)
                id = find_single_match(req, video_match_string)
                if id is not "":
                    return get_playable_url(id)
                else:
                    # Report Stream
                    open_url(base64.b64decode(report_stream) + 'Aljazeera')
                    return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Aljazeera')
            return None

    @staticmethod
    def bloomberg():
        try:
            req = open_url(base64.b64decode(
                'aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvbGl2ZXR2X2RpcmVjdC92MS9nZXRfc3RyZWFtLnBocD9pZD0=') + 'bloomberg')
            bloomberg_json = json.loads(req)
            stream = bloomberg_json["results"][0]["stream"]

            if "m3u8" in stream and stream != "null":
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'Bloomberg')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Bloomberg')
            return None


    @staticmethod
    def buzzr():
        try:
            site_url = "http://buzzrplay.com/watch"
            match_string = '<source src="(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string) + "?rebase=on"
            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'Buzzr')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Buzzr')
            return None

    @staticmethod
    def catholic_tv():
        try:
            site_url = "http://www.catholictv.org/watch-live"
            player_match_string = '<iframe src="(.*?)"'
            stream_match_string = 'tp:releaseUrl="(.*?)\?'

            # Get Player
            req = open_url(site_url)
            url = find_single_match(req, player_match_string)

            # Get Stream
            req = open_url(url)
            stream = find_single_match(req, stream_match_string) + "?formats=m3u"

            if stream is not "":
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'CatholicTV')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'CatholicTV')
            return None

    @staticmethod
    def cbs_news():
        try:
            site_url = "https://www.cbsnews.com/live/"
            match_string = '"video":"(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string) + "?rebase=on"
            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'CBS_News')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'CBS_News')
            return None

    @staticmethod
    def cbs_sports_hq():
        try:
            site_url = "https://www.cbsnews.com/live/cbs-sports-hq/"
            match_string = '"video":"(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string) + "?rebase=on"
            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'CBS_Sports_HQ')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'CBS_Sports_HQ')
            return None

    @staticmethod
    def charge():
        try:
            site_url = "https://watchcharge.com/watch-live/"
            match_string = 'file: "(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string)
            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'Charge!')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Charge!')
            return None

    @staticmethod
    def comet():
        try:
            site_url = "https://www.comettv.com/watch-live/"
            match_string = '	file: "(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string)
            if stream is not "":
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'Comet')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Comet')
            return None

    @staticmethod
    def et_live():
        try:
            site_url = "https://www.cbsnews.com/live/et-live/"
            match_string = '"video":"(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string) + "?rebase=on"
            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'ET_Live')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'ET_Live')
            return None

    @staticmethod
    def hsn():
        try:
            hsn1_url = "https://www.hsn.com/watch/live"
            hsn2_url = "https://www.hsn.com/watch/live?network=4"
            stream_id_match_string = "watchTemplate.PlayLiveYoutubeVideo\('(.+?)'"
            program_match_string = '<span class="show-title" id="show-title" tabindex="0">(.+?)</span>'

            # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
            yt_addon = xbmcaddon.Addon('plugin.video.youtube')
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                dlg.ok('HSN', youtube_message)
                yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
                xbmc.executebuiltin("yt_settings")
            else:
                # Get HSN TV current program info
                req = open_url(hsn1_url)
                hsn1_program = find_single_match(req, program_match_string).replace("&amp;", "&")

                # Get HSN2 TV current program info
                req = open_url(hsn2_url)
                hsn2_program = find_single_match(req, program_match_string).replace("&amp;", "&")

                # Channel Selection
                source = xbmcgui.Dialog().select("Choose Channel", [
                    "[COLOR blue]HSN TV:[/COLOR] " + hsn1_program,
                    "[COLOR blue]HSN2 TV:[/COLOR] " + hsn2_program
                ])
                if source == 0:
                    channel_url = hsn1_url
                if source == 1:
                    channel_url = hsn2_url
                if source < 0:
                    exit()

                # Get HSN TV or HSN2 TV stream depending on Channel Selection
                req = open_url(channel_url)
                id = find_single_match(req, stream_id_match_string)
                if id is not "":
                    return get_playable_url(id)
                else:
                    # Report Stream
                    open_url(base64.b64decode(report_stream) + 'HSN')
                    return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'HSN')
            return None

    @staticmethod
    def light_tv():
        try:
            site_url = "http://www.lighttv.com/"
            embed_match_string = 'frameborder="0" scrolling="no" src="(.+?)"'
            tokens_match_string = 'tokens=(.+?)"'
            stream_match_string = 'src: "(.+?)"'

            # Get embed url
            req = open_url(site_url)
            embed_url = find_single_match(req, embed_match_string)

            # Get tokens
            req = open_url(site_url)
            tokens = find_single_match(req, tokens_match_string)

            # Get stream url
            req = open_url(embed_url)
            stream = find_single_match(req, stream_match_string) + tokens

            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'LightTV')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'LightTV')
            return None

    @staticmethod
    def newsmax_tv():
        try:
            site_url = "https://www.newsmaxtv.com/"
            embed_match_string = '"embedUrl": "(.+?)"'
            stream_match_string = 'hlsStreamUrl(.+?)",'

            # Get embed url
            req = open_url(site_url)
            embed_url = find_single_match(req, embed_match_string)

            # Get stream url
            req = open_url(embed_url)
            stream = find_single_match(req, stream_match_string).replace('\\":\\"', '').replace('\\\\\\', '').replace('\\',
                                                                                                                      '')

            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'Newsmax')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Newsmax')
            return None

    @staticmethod
    def pbs_kids():
        try:
            json_url = 'http://pbskids.org/api/video/v1/livestream'

            # Get stream url
            req = open_url(json_url)
            pbs_kids_json = json.loads(req)
            stream = pbs_kids_json["livestream"] + "?rebase=on"

            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'PBS_Kids')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'PBS_Kids')
            return None

    @staticmethod
    def qvc():
        try:
            site_url = "http://www.qvc.com/content/shop-live-tv.html"
            json_match_string = "var oLiveStreams=(.+?),\n"

            # Get QVC json
            req = open_url(site_url)
            qvc_json = json.loads(find_single_match(req, json_match_string))

            qvc_url = qvc_json["QVC"]["url"]
            qvc2_url = qvc_json["2CH"]["url"]
            iq_url = qvc_json["STA"]["url"]

            # Channel Selection
            source = xbmcgui.Dialog().select("Choose Channel", [
                "[COLOR blue]QVC[/COLOR]",
                "[COLOR blue]QVC2[/COLOR]",
                "[COLOR blue]Beauty IQ[/COLOR]"
            ])
            if source == 0:
                channel_url = qvc_url
            if source == 1:
                channel_url = qvc2_url
            if source == 2:
                channel_url = iq_url
            if source < 0:
                exit()

            # Play QVC stream depending on Channel Selection
            stream = "http:" + channel_url + "?rebase=on"
            if "m3u8" in channel_url:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'QVC')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'QVC')
            return None

    @staticmethod
    def revn_tv():
        try:
            site_url = "http://www.revntv.com/watch/watch-online/"
            embed_match_string = '<iframe src="(.+?)"'
            tokens_match_string = '<script id="(.+?)"'
            json_url_main = 'http://json.dacast.com/b/'

            # Get embed url
            req = open_url(site_url)
            embed_url = "http:" + find_single_match(req, embed_match_string)

            # Get tokens
            req = open_url(embed_url)
            tokens = find_single_match(req, tokens_match_string).replace("_", "/")

            # Build json url
            json_url = json_url_main + tokens

            # Get stream url
            req = open_url(json_url)
            revn_json = json.loads(req)
            stream = revn_json["hls"] + "?rebase=on"

            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'Revn')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Revn')
            return None

    @staticmethod
    def rt():
        try:
            rt_url = "https://www.rt.com/on-air/"
            rtus_url = "https://www.rt.com/on-air/rt-america-air/"
            rtuk_url = "https://www.rt.com/on-air/rt-uk-air/"
            rtfr_url = "https://francais.rt.com/en-direct"
            rtar_url = "https://arabic.rt.com/live/"
            rtesp_url = "https://actualidad.rt.com/en_vivo"
            rtdoc_url = "https://rtd.rt.com/on-air/"
            stream_id_match_string = "file: '(.+?)'"
            stream_france_id_match_string = 'file: "(.+?)"'
            stream_arabic_id_match_string = "file': '(.+?)'"
            stream_spanish_id_match_string = "embed/(.+?)\?"
            stream_doc_id_match_string = 'url: "(.+?)"'

            # Channel Selection
            source = xbmcgui.Dialog().select("Choose Channel", [
                "[COLOR blue]RT Global[/COLOR]",
                "[COLOR blue]RT America[/COLOR]",
                "[COLOR blue]RT UK[/COLOR]",
                "[COLOR blue]RT France[/COLOR]",
                "[COLOR blue]RT Arabic[/COLOR]",
                "[COLOR blue]RT Spanish[/COLOR]",
                "[COLOR blue]RT Documentary[/COLOR]"
            ])
            if source == 0:
                channel_url = rt_url
                match_string = stream_id_match_string
                vid_name = "RT Global"
            if source == 1:
                channel_url = rtus_url
                match_string = stream_id_match_string
                vid_name = "RT America"
            if source == 2:
                channel_url = rtuk_url
                match_string = stream_id_match_string
                vid_name = "RT UK"
            if source == 3:
                channel_url = rtfr_url
                match_string = stream_france_id_match_string
                vid_name = "RT France"
            if source == 4:
                channel_url = rtar_url
                match_string = stream_arabic_id_match_string
                vid_name = "RT Arabic"
            if source == 5:
                vid_name = "RT Spanish"

                # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
                yt_addon = xbmcaddon.Addon('plugin.video.youtube')
                if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                    dlg.ok(vid_name,
                           "This channel requires MPEG-DASH to be enabled in the YouTube addon. Once enabled try again.")
                    yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
                    xbmc.executebuiltin("yt_settings")
                    exit()
                else:
                    channel_url = rtesp_url
                    match_string = stream_spanish_id_match_string
            if source == 6:
                channel_url = rtdoc_url
                match_string = stream_doc_id_match_string
                vid_name = "RT Documentary"
            if source < 0:
                exit()

            # Get RT stream depending on Channel Selection
            req = open_url(channel_url)

            # Use YouTube for RT Spanish Streams
            if source == 5:
                id = find_single_match(req, match_string)
                if id is not "":
                    return get_playable_url(id)
                else:
                    # Report Stream
                    open_url(base64.b64decode(report_stream) + 'RT')
                    return None

            # Stream direct for streams other than RT Spanish
            else:
                stream = find_single_match(req, match_string)
                if "m3u8" in stream:
                    return stream
                else:
                    # Report Stream
                    open_url(base64.b64decode(report_stream) + 'RT')
                    return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'RT')
            return None

    @staticmethod
    def sky_news():
        try:
            site_url = "https://news.sky.com/watch-live"
            match_string = 'embed/(.+?)\?'

            yt_addon = xbmcaddon.Addon('plugin.video.youtube')
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                dlg.ok('Sky News', youtube_message)
                yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
                xbmc.executebuiltin("yt_settings")
            else:
                req = open_url(site_url)
                id = find_single_match(req, match_string)
                if id is not "":
                    return get_playable_url(id)
                else:
                    # Report Stream
                    open_url(base64.b64decode(report_stream) + 'Sky_News')
                    return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Sky_News')
            return None

    @staticmethod
    def stadium():
        try:
            site_url = "https://watchstadium.com/live/"
            player_string = '"src":"(.+?)"'
            stream_match_string = '"m3u8_url":"(.+?)"'

            # Get Stadium Player
            req = open_url(site_url)
            player_url = find_single_match(req, player_string).replace("\\", "")

            # Get Stadium Stream
            req = open_url(player_url)
            stream = find_single_match(req, stream_match_string)

            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'Stadium')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'Stadium')
            return None

    @staticmethod
    def tbd():
        try:
            site_url = "http://tbd.com/"
            match_string = '\'file\': "(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string)
            if stream is not "":
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'TBD')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'TBD')
            return None

    @staticmethod
    def the_country_network():
        try:
            site_url = "http://tcncountry.net/watch-live.htm"
            embed_match_string = '<iframe src="(.+?)"'
            tokens_match_string = '<script id="(.+?)"'
            json_url_main = 'http://json.dacast.com/b/'

            # Get embed url
            req = open_url(site_url)
            embed_url = find_single_match(req, embed_match_string)

            # Get tokens
            req = open_url(embed_url)
            tokens = find_single_match(req, tokens_match_string).replace("_", "/")

            # Build json url
            json_url = json_url_main + tokens

            # Get stream url
            req = open_url(json_url)
            tcn_json = json.loads(req)
            stream = tcn_json["hls"] + "?rebase=on"

            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + 'The_Country_Network')
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + 'The_Country_Network')
            return None

    @staticmethod
    def campfire(channel):
        try:
            if channel == 'radiou':
                id = 'XDc'
                channel_name = 'RadioU'
            elif channel == 'spirit_tv':
                id = 'bqg'
                channel_name = 'SpiritTV'

            site_url = "http://player.campfyre.tv/{id}".format(id=id)
            match_string = 'file: "(.+?)"'

            req = open_url(site_url)
            stream = "http:" + find_single_match(req, match_string)
            if "m3u8" in stream:
                return stream
            else:
                # Report Stream
                open_url(base64.b64decode(report_stream) + channel_name)
                return None
        except:
            # Report Stream
            open_url(base64.b64decode(report_stream) + channel_name)
            return None
