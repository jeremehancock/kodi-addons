"""
    m7lib

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Checkout the Free Live TV addon for an example of how to use m7lib
    https://github.com/mhancoc7/kodi-addons/tree/master/_repo/plugin.video.freelivetv.tva
"""

import os
import json
import base64
import re
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import sys
import string
import random

try:
    # Python 2
    from urllib2 import urlopen, Request
except ImportError:
    # Python 3
    from urllib.request import urlopen, Request

try:
    # Python 2
    from HTMLParser import HTMLParser
except ImportError:
    # Python 3
    from html.parser import HTMLParser

convert_special_characters = HTMLParser()
dlg = xbmcgui.Dialog()

yt_addon = xbmcaddon.Addon('plugin.video.youtube')
youtube_message = "This channel requires MPEG-DASH to be enabled in the YouTube addon. Once enabled try again."
stream_failed = "Unable to get stream. Please try again later."
stream_plug = "aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvbGl2ZXR2X2RpcmVjdC92MS9nZXRfc3RyZWFtLnBocD9pZD0="


class Common:

    @staticmethod
    def random_generator(size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for x in range(size))

    @staticmethod
    def youtube_settings(channel):
        dlg.ok(channel, youtube_message)
        yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
        xbmc.executebuiltin(str(yt_settings))

    @staticmethod
    # Parse string and extracts first match as a string
    def find_single_match(text, pattern):
        try:
            matches = re.findall(pattern, text, flags=re.DOTALL)
            result = matches[0]
        except StandardError:
            result = ""
        return result

    @staticmethod
    # Open URL
    def open_url(url):
        req = Request(url)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 '
                       '(KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
        response = urlopen(req)
        link = response.read()
        response.close()
        return link

    @staticmethod
    # Channel logos
    def get_logo(channel):
        return xbmc.translatePath(
            os.path.join('special://home/addons/script.module.m7lib', 'lib', 'resources', 'images', channel + ".png"))

    @staticmethod
    # Available channels
    def get_channels():
        channel_list = ["24-7 Retro", "Aljazeera", "Bloomberg", "Buzzr", "Catholic TV Network", "CBS News",
                        "CBS Sports HQ", "Celebrity Page Network", "Charge!", "Comet", "ET Live", "HSN", "Light TV",
                        "NASA TV", "Newsmax", "PBS Kids", "QVC", "RadioU", "Rev'n TV", "RT News", "Sky News",
                        "Spirit TV", "Stadium", "TBD", "The Country Network"]
        return channel_list

    @staticmethod
    def add_channel(mode, icon, fanart):
        u = sys.argv[0] + "?mode=" + str(mode) + "&rand=" + Common.random_generator()
        ok = True
        liz = xbmcgui.ListItem(str(mode), iconImage="DefaultFolder.png", thumbnailImage=icon)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable", "true")
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
        return ok

    @staticmethod
    # Return the Channel ID from YouTube URL
    def get_youtube_channel_id(url):
        return url.split("?v=")[-1].split("/")[-1].split("?")[0].split("&")[0]

    @staticmethod
    # Return the full YouTube plugin url
    def get_playable_youtube_url(channel_id):
        return 'plugin://plugin.video.youtube/play/?video_id=%s' % channel_id

    @staticmethod
    # Add rebase=on to stream URL
    def rebase(stream):
        rebase = 'rebase=on'
        if '?' in stream:
            return stream + '&' + rebase
        return stream + '?' + rebase

    @staticmethod
    # Play stream
    # Optional: set xbmc_player to True to use xbmc.Player() instead of xbmcplugin.setResolvedUrl()
    def play(stream, channel=None, xbmc_player=False):
        if xbmc_player:
            li = xbmcgui.ListItem(channel)
            xbmc.Player().play(stream, li, False)
        else:
            item = xbmcgui.ListItem(channel, path=stream)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

    @staticmethod
    # Get and Play stream
    # Optional: set xbmc_player to True to use xbmc.Player() instead of xbmcplugin.setResolvedUrl()
    def get_stream_and_play(mode, xbmc_player=False):
        if mode == "24-7 Retro":
            stream = Stream.twenty_four_seven_retro()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Aljazeera":
            stream = Stream.aljazeera()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Bloomberg":
            stream = Stream.bloomberg()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Buzzr":
            stream = Stream.buzzr()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Catholic TV Network":
            stream = Stream.catholic_tv()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "CBS News":
            stream = Stream.cbs_news()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "CBS Sports HQ":
            stream = Stream.cbs_sports_hq()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Celebrity Page Network":
            stream = Stream.celebrity_page_network()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Charge!":
            stream = Stream.charge()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Comet":
            stream = Stream.comet()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "ET Live":
            stream = Stream.et_live()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "HSN":
            stream = Stream.hsn()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Light TV":
            stream = Stream.light_tv()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "NASA TV":
            stream = Stream.nasa_tv()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Newsmax":
            stream = Stream.newsmax_tv()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "PBS Kids":
            stream = Stream.pbs_kids()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "QVC":
            stream = Stream.qvc()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "RadioU":
            stream = Stream.campfire(mode)
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Rev'n TV":
            stream = Stream.revn_tv()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "RT News":
            stream = Stream.rt()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Sky News":
            stream = Stream.sky_news()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Spirit TV":
            stream = Stream.campfire(mode)
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "Stadium":
            stream = Stream.stadium()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "TBD":
            stream = Stream.tbd()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)

        elif mode == "The Country Network":
            stream = Stream.the_country_network()
            if stream is not None:
                Common.play(stream, mode, xbmc_player)
            else:
                dlg.ok(mode, stream_failed)


class Stream:

    @staticmethod
    def twenty_four_seven_retro():
        try:
            site_url = "http://www.247retro.com/"
            match_string = 'src: "(.+?)"'
            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def aljazeera():
        channel = 'Aljazeera'
        try:
            site_url = "https://www.aljazeera.com/live/"
            channel_match_string = '<iframe width="100%" src="(.+?)\&'
            video_match_string = '\'VIDEO_ID\': "(.+?)"'

            # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                Common.youtube_settings(channel)
            else:
                # Get A Jazerra YouTube Channel
                req = Common.open_url(site_url)
                channel_url = Common.find_single_match(req, channel_match_string)

                # Get Stream
                req = Common.open_url(channel_url)
                channel_id = Common.find_single_match(req, video_match_string)
                if channel_id is not "":
                    return Common.get_playable_youtube_url(channel_id)
                else:
                    return None
        except StandardError:
            return None

    @staticmethod
    def bloomberg():
        try:
            req = Common.open_url(
                base64.b64decode(stream_plug) + 'bloomberg')
            bloomberg_json = json.loads(req)
            stream = bloomberg_json["results"][0]["stream"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            elif "youtube" in stream:
                channel_id = Common.get_youtube_channel_id(stream)
                return Common.get_playable_youtube_url(channel_id)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def buzzr():
        try:
            site_url = "http://buzzrplay.com/watch"
            match_string = '<source src="(.+?)"'

            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def catholic_tv():
        try:
            site_url = "http://www.catholictv.org/watch-live"
            player_match_string = '<iframe src="(.*?)"'
            stream_match_string = 'tp:releaseUrl="(.*?)\?'

            # Get Player
            req = Common.open_url(site_url)
            url = Common.find_single_match(req, player_match_string)

            # Get Stream
            req = Common.open_url(url)
            stream = Common.find_single_match(req, stream_match_string) + "?formats=m3u"

            if stream is not "":
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def cbs_news():
        try:
            site_url = "https://www.cbsnews.com/live/"
            match_string = '"video":"(.+?)"'

            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def cbs_sports_hq():
        try:
            site_url = "https://www.cbsnews.com/live/cbs-sports-hq/"
            match_string = '"video":"(.+?)"'

            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def celebrity_page_network():
        try:
            req = Common.open_url(
                base64.b64decode(stream_plug) + 'celebrity_page_network')
            celebrity_page_json = json.loads(req)
            stream = celebrity_page_json["results"][0]["stream"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            elif "youtube" in stream:
                channel_id = Common.get_youtube_channel_id(stream)
                return Common.get_playable_youtube_url(channel_id)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def charge():
        try:
            site_url = "https://watchcharge.com/watch-live/"
            match_string = 'file: "(.+?)"'

            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                # Charge! doesn't work with rebase=on so just returning the stream
                return stream
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def comet():
        try:
            site_url = "https://www.comettv.com/watch-live/"
            match_string = '	file: "(.+?)"'

            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if stream is not "":
                # Comet is part of the same company as Charge! and TBD
                # Comet seems to work with rebase=on. However, Charge! and TBD don't
                # Since they are all very similar it is safer to not use rebase=on for Comet
                return stream
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def et_live():
        try:
            site_url = "https://www.cbsnews.com/live/et-live/"
            match_string = '"video":"(.+?)"'

            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def hsn():
        channel = 'HSN'
        channel_url = ""
        try:
            hsn1_url = "https://www.hsn.com/watch/live"
            hsn2_url = "https://www.hsn.com/watch/live?network=4"
            stream_id_match_string = "watchTemplate.PlayLiveYoutubeVideo\('(.+?)'"
            program_match_string = '<span class="show-title" id="show-title" tabindex="0">(.+?)</span>'

            # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                Common.youtube_settings(channel)
            else:
                # Get HSN TV current program info
                req = Common.open_url(hsn1_url)
                hsn1_program = Common.find_single_match(req, program_match_string).replace("&amp;", "&")

                # Get HSN2 TV current program info
                req = Common.open_url(hsn2_url)
                hsn2_program = Common.find_single_match(req, program_match_string).replace("&amp;", "&")

                # Channel Selection
                source = xbmcgui.Dialog().select("Choose Channel", [
                    "[COLOR blue]HSN TV:[/COLOR] " + convert_special_characters.unescape(hsn1_program),
                    "[COLOR blue]HSN2 TV:[/COLOR] " + convert_special_characters.unescape(hsn2_program)
                ])
                if source == 0:
                    channel_url = hsn1_url
                if source == 1:
                    channel_url = hsn2_url
                if source < 0:
                    exit()

                # Get HSN TV or HSN2 TV stream depending on Channel Selection
                req = Common.open_url(channel_url)
                channel_id = Common.find_single_match(req, stream_id_match_string)
                if channel_id is not "":
                    return Common.get_playable_youtube_url(channel_id)
                else:
                    return None
        except StandardError:
            return None

    @staticmethod
    def light_tv():
        try:
            site_url = "http://www.lighttv.com/"
            embed_match_string = 'frameborder="0" scrolling="no" src="(.+?)"'
            tokens_match_string = 'tokens=(.+?)"'
            stream_match_string = 'src: "(.+?)"'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get tokens
            req = Common.open_url(site_url)
            tokens = Common.find_single_match(req, tokens_match_string)

            # Get stream url
            req = Common.open_url(embed_url)
            stream = Common.find_single_match(req, stream_match_string) + tokens

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def nasa_tv():
        try:
            # Get NASA TV Media Channel Stream
            req = Common.open_url(
                base64.b64decode(stream_plug) + 'nasa_tv')
            nasa_tv_json = json.loads(req)
            nasa_tv_url = nasa_tv_json["results"][0]["stream"]

            # Get NASA TV Space Station Channel Stream
            req = Common.open_url(
                base64.b64decode(stream_plug) + 'nasa_tv_2')
            nasa_tv_2_json = json.loads(req)
            nasa_tv_2_url = nasa_tv_2_json["results"][0]["stream"]

            # Channel Selection
            source = xbmcgui.Dialog().select("Choose Channel", [
                "[COLOR blue]NASA TV's Media Channel[/COLOR]",
                "[COLOR blue]Earth Views from the Space Station[/COLOR]",
            ])
            if source == 0:
                stream = nasa_tv_url
            if source == 1:
                stream = nasa_tv_2_url
            if source < 0:
                exit()

            # Play NASA TV stream depending on Channel Selection
            if "m3u8" in stream:
                return Common.rebase(stream)
            elif "youtube" in stream:
                channel_id = Common.get_youtube_channel_id(stream)
                return Common.get_playable_youtube_url(channel_id)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def newsmax_tv():
        try:
            site_url = "https://www.newsmaxtv.com/"
            embed_match_string = '"embedUrl": "(.+?)"'
            stream_match_string = 'hlsStreamUrl(.+?)",'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get stream url
            req = Common.open_url(embed_url)
            stream = Common.find_single_match(req, stream_match_string)\
                .replace('\\":\\"', '')\
                .replace('\\\\\\', '')\
                .replace('\\', '')

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def pbs_kids():
        try:
            json_url = 'http://pbskids.org/api/video/v1/livestream'

            # Get stream url
            req = Common.open_url(json_url)
            pbs_kids_json = json.loads(req)
            stream = pbs_kids_json["livestream"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def qvc():
        channel_url = ""
        try:
            site_url = "http://www.qvc.com/content/shop-live-tv.html"
            json_match_string = "var oLiveStreams=(.+?),\n"

            # Get QVC json
            req = Common.open_url(site_url)
            qvc_json = json.loads(Common.find_single_match(req, json_match_string))

            qvc_url = qvc_json["QVC"]["url"]
            qvc2_url = qvc_json["2CH"]["url"]
            iq_url = qvc_json["STA"]["url"]

            # Channel Selection
            source = xbmcgui.Dialog().select("Choose Channel", [
                "[COLOR blue]QVC[/COLOR]",
                "[COLOR blue]QVC2[/COLOR]",
                "[COLOR blue]Beauty IQ[/COLOR]"
            ])
            if source == 0:
                channel_url = qvc_url
            if source == 1:
                channel_url = qvc2_url
            if source == 2:
                channel_url = iq_url
            if source < 0:
                exit()

            # Play QVC stream depending on Channel Selection
            stream = "http:" + channel_url
            if "m3u8" in channel_url:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def revn_tv():
        try:
            site_url = "http://www.revntv.com/watch/watch-online/"
            embed_match_string = '<iframe src="(.+?)"'
            tokens_match_string = '<script id="(.+?)"'
            json_url_main = 'http://json.dacast.com/b/'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = "http:" + Common.find_single_match(req, embed_match_string)

            # Get tokens
            req = Common.open_url(embed_url)
            tokens = Common.find_single_match(req, tokens_match_string).replace("_", "/")

            # Build json url
            json_url = json_url_main + tokens

            # Get stream url
            req = Common.open_url(json_url)
            revn_json = json.loads(req)
            stream = revn_json["hls"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def rt():
        channel_url = ""
        match_string = ""
        try:
            rt_url = "https://www.rt.com/on-air/"
            rtus_url = "https://www.rt.com/on-air/rt-america-air/"
            rtuk_url = "https://www.rt.com/on-air/rt-uk-air/"
            rtfr_url = "https://francais.rt.com/en-direct"
            rtar_url = "https://arabic.rt.com/live/"
            rtesp_url = "https://actualidad.rt.com/en_vivo"
            rtdoc_url = "https://rtd.rt.com/on-air/"
            stream_id_match_string = "file: '(.+?)'"
            stream_france_id_match_string = 'file: "(.+?)"'
            stream_arabic_id_match_string = "file': '(.+?)'"
            stream_spanish_id_match_string = "embed/(.+?)\?"
            stream_doc_id_match_string = 'url: "(.+?)"'

            # Channel Selection
            source = xbmcgui.Dialog().select("Choose Channel", [
                "[COLOR blue]RT Global[/COLOR]",
                "[COLOR blue]RT America[/COLOR]",
                "[COLOR blue]RT UK[/COLOR]",
                "[COLOR blue]RT France[/COLOR]",
                "[COLOR blue]RT Arabic[/COLOR]",
                "[COLOR blue]RT Spanish[/COLOR]",
                "[COLOR blue]RT Documentary[/COLOR]"
            ])
            if source == 0:
                channel_url = rt_url
                match_string = stream_id_match_string
            if source == 1:
                channel_url = rtus_url
                match_string = stream_id_match_string
            if source == 2:
                channel_url = rtuk_url
                match_string = stream_id_match_string
            if source == 3:
                channel_url = rtfr_url
                match_string = stream_france_id_match_string
            if source == 4:
                channel_url = rtar_url
                match_string = stream_arabic_id_match_string
            if source == 5:
                channel_name = "RT Spanish"

                # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
                if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                    Common.youtube_settings(channel_name)
                    exit()
                else:
                    channel_url = rtesp_url
                    match_string = stream_spanish_id_match_string
            if source == 6:
                channel_url = rtdoc_url
                match_string = stream_doc_id_match_string
            if source < 0:
                exit()

            # Get RT stream depending on Channel Selection
            req = Common.open_url(channel_url)

            # Use YouTube for RT Spanish Streams
            if source == 5:
                channel_id = Common.find_single_match(req, match_string)
                if channel_id is not "":
                    return Common.get_playable_youtube_url(channel_id)
                else:
                    return None

            # Stream direct for streams other than RT Spanish
            else:
                stream = Common.find_single_match(req, match_string)
                if "m3u8" in stream:
                    return Common.rebase(stream)
                else:
                    return None
        except StandardError:
            return None

    @staticmethod
    def sky_news():
        channel = 'Sky News'
        try:
            site_url = "https://news.sky.com/watch-live"
            match_string = 'embed/(.+?)\?'

            # Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
            if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
                Common.youtube_settings(channel)
            else:
                req = Common.open_url(site_url)
                channel_id = Common.find_single_match(req, match_string)
                if channel_id is not "":
                    return Common.get_playable_youtube_url(channel_id)
                else:
                    return None
        except StandardError:
            return None

    @staticmethod
    def stadium():
        try:
            site_url = "https://watchstadium.com/live/"
            player_string = '"src":"(.+?)"'
            stream_match_string = '"m3u8_url":"(.+?)"'

            # Get Stadium Player
            req = Common.open_url(site_url)
            player_url = Common.find_single_match(req, player_string).replace("\\", "")

            # Get Stadium Stream
            req = Common.open_url(player_url)
            stream = Common.find_single_match(req, stream_match_string)

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def tbd():
        try:
            site_url = "http://tbd.com/"
            match_string = '\'file\': "(.+?)"'

            req = Common.open_url(site_url)
            stream = Common.find_single_match(req, match_string)
            if stream is not "":
                # TBD doesn't work with rebase=on so just returning the stream
                return stream
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def the_country_network():
        try:
            site_url = "http://tcncountry.net/watch-live.htm"
            embed_match_string = '<iframe src="(.+?)"'
            tokens_match_string = '<script id="(.+?)"'
            json_url_main = 'http://json.dacast.com/b/'

            # Get embed url
            req = Common.open_url(site_url)
            embed_url = Common.find_single_match(req, embed_match_string)

            # Get tokens
            req = Common.open_url(embed_url)
            tokens = Common.find_single_match(req, tokens_match_string).replace("_", "/")

            # Build json url
            json_url = json_url_main + tokens

            # Get stream url
            req = Common.open_url(json_url)
            tcn_json = json.loads(req)
            stream = tcn_json["hls"]

            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None

    @staticmethod
    def campfire(channel):
        channel_id = ""
        try:
            if channel == 'RadioU':
                channel_id = 'XDc'
            elif channel == 'Spirit TV':
                channel_id = 'bqg'

            site_url = "http://player.campfyre.tv/{id}".format(id=channel_id)
            match_string = 'file: "(.+?)"'

            req = Common.open_url(site_url)
            stream = "http:" + Common.find_single_match(req, match_string)
            if "m3u8" in stream:
                return Common.rebase(stream)
            else:
                return None
        except StandardError:
            return None
