"""
    Free Live TV Add-on
    Developed by mhancoc7

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmcplugin
import xbmcgui
import os
import sys
import string
import xbmcaddon
import xbmc
import random

dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
tvaddons_logo = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'tvaddons_logo.png'))
icon = xbmc.translatePath(os.path.join(plugin_path, 'icon.png'))
fanart = xbmc.translatePath(os.path.join(plugin_path, 'icon.png'))


def tvaddons_branding():
    # TVADDONS Branding
    if len(get_setting('branding_notify')) > 0:
        set_setting('branding_notify', str(int(get_setting('branding_notify')) + 1))
    else:
        set_setting('branding_notify', "1")
    if int(get_setting('branding_notify')) == 1:
        dlg.notification(get_string(9004), get_string(9003), tvaddons_logo, 5000, False)
    elif int(get_setting('branding_notify')) == 9:
        set_setting('branding_notify', "0")

    # VPN Message
    if int(get_setting('vpn_notify')) != 1:
        dlg.ok(addon_name, get_string(9005))
        set_setting('vpn_notify', "1")


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)


def set_setting(setting, string):
    return addon.setSetting(setting, string)


def get_string(string_id):
    return addon.getLocalizedString(string_id)
