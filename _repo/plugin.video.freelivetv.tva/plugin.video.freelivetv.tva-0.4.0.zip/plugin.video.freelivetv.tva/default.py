"""
    Free Live TV Add-on
    Developed by mhancoc7

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resources.lib.modules.channels import *
import urllib

def main():
    # TVADDONS Branding
    if len(get_setting('branding_notify')) > 0:
        set_setting('branding_notify', str(int(get_setting('branding_notify')) + 1))
    else:
        set_setting('branding_notify', "1")
    if int(get_setting('branding_notify')) == 1:
        dlg.notification(get_string(9004), get_string(9003), tvaddons_logo, 5000, False)
    elif int(get_setting('branding_notify')) == 9:
        set_setting('branding_notify', "0")

    # VPN Message
    if int(get_setting('vpn_notify')) != 1:
        dlg.ok(addon_name, get_string(9005))
        set_setting('vpn_notify', "1")

    # Channel Array
    channels = ["24-7 Retro", "Aljazeera", "Bloomberg", "Buzzr", "Catholic TV Network", "CBS News", "Charge!",
                "Comet", "HSN", "Light TV", "Newsmax", "PBS Kids", "QVC", "RadioU", "Rev'n TV", "RT News",
                "Sky News", "Spirit TV", "Stadium", "TBD", "The Country Network"]

    # Generate Channel List
    for channel in channels:
        add_link(channel, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', channel + ".png")))

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param

params = get_params()
mode = None

try:
    mode = urllib.unquote_plus(params["mode"])
except:
    pass

if mode is None:
    main()

elif mode == "24-7 Retro":
    Channel().play_247retro()

elif mode == "Aljazeera":
    Channel().play_aljazeera()

elif mode == "Bloomberg":
    Channel().play_bloomberg()

elif mode == "Buzzr":
    Channel().play_buzzr()

elif mode == "Catholic TV Network":
    Channel().play_catholic_tv()

elif mode == "CBS News":
    Channel.play_cbs_news()

elif mode == "Charge!":
    Channel().play_charge()

elif mode == "Comet":
    Channel().play_comet()

elif mode == "HSN":
    Channel().play_hsn()

elif mode == "Light TV":
    Channel().play_light_tv()

elif mode == "Newsmax":
    Channel().play_newsmax_tv()

elif mode == "PBS Kids":
    Channel().play_pbs_kds()

elif mode == "QVC":
    Channel().play_qvc()

elif mode == "RadioU":
    Channel().play_campfire('radiou')

elif mode == "Rev'n TV":
    Channel().play_revn_tv()

elif mode == "RT News":
    Channel().play_rt()

elif mode == "Sky News":
    Channel().play_sky_news()

elif mode == "Spirit TV":
    Channel().play_campfire('spirit_tv')

elif mode == "Stadium":
    Channel().play_stadium()

elif mode == "TBD":
    Channel().play_tbd()

elif mode == "The Country Network":
    Channel().play_the_country_network()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
