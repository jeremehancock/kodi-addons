'''
    Free Live TV Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys,re,os,urllib,urllib2
from urllib2 import urlopen
import xbmc,xbmcgui,xbmcplugin,xbmcaddon

dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
addon_logo = xbmc.translatePath(os.path.join(plugin_path,'tvaddons_logo.png'))

def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string) 

if __name__ == '__main__':
    #TVADDONS Branding
    dlg.notification(addon_name + ' is provided by:','www.tvaddons.co',addon_logo,10000,False)

    #VPN Message
    if int(get_setting('notify')) != 1:
        dlg.ok(addon_name, "If you are outside the USA, you might want to consider subscribing to a VPN service in order to take full advantage of this addon. Sign up: [COLOR blue]www.tvaddons.co/vpn[/COLOR]")
        set_setting('notify', "1") 
    
    #Push to Home Screen Just makes transitions look better
    xbmc.executebuiltin('Activatewindow(home)')

    #Channel Selection
    source = dlg.select("Choose Channel", [
        "[COLOR blue]Al Jazeera[/COLOR]",
        "[COLOR blue]Bloomberg Global News[/COLOR]",
        "[COLOR blue]CBS News[/COLOR]",
        "[COLOR blue]Charge![/COLOR]",
        "[COLOR blue]Cheddar[/COLOR]",
        "[COLOR blue]Comet TV[/COLOR]",
        "[COLOR blue]France 24[/COLOR]",
        "[COLOR blue]HSN TV[/COLOR]",
        "[COLOR blue]Light TV[/COLOR]",
        "[COLOR blue]Newsmax TV[/COLOR]",
        "[COLOR blue]Newsy[/COLOR]",
        "[COLOR blue]QVC[/COLOR]",
        "[COLOR blue]Rev'n TV[/COLOR]",
        "[COLOR blue]RT News[/COLOR]",
        "[COLOR blue]Sky News[/COLOR]",
        "[COLOR blue]Stadium[/COLOR]",
        "[COLOR blue]TBD TV[/COLOR]",
        "[COLOR blue]The Country Network[/COLOR]",
        "[COLOR blue]Tuff TV[/COLOR]"])
    if source == 0:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.aljazeera.tva')
    if source == 1:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.bloomberg.tva')
    if source == 2:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.cbsnews.tva')
    if source == 3:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.charge.tva')
    if source == 4:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.cheddar.tva')
    if source == 5:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.comet.tva')
    if source == 6:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.france24.tva')
    if source == 7:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.hsn.tva')
    if source == 8:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.lighttv.tva')
    if source == 9:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.newsmaxtv.tva')
    if source == 10:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.newsylive.tva')
    if source == 11:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.qvc.tva')
    if source == 12:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.revn.tva')
    if source == 13:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.rt.tva')
    if source == 14:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.skynews.tva')
    if source == 15:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.stadium.tva')
    if source == 16:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.tbd.tva')
    if source == 17:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.countrynetwork.tva')
    if source == 18:
        xbmc.executebuiltin('XBMC.RunPlugin(%s)' % 'plugin://plugin.video.tufftv.tva')
    if source < 0:
        xbmc.executebuiltin('Activatewindow(home)')
        exit()
