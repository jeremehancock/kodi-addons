"""
    Free Live TV Add-on
    Developed by mhancoc7

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resources.lib.modules.channels import *


def main():
    # TVADDONS Branding
    if len(get_setting('branding_notify')) > 0:
        set_setting('branding_notify', str(int(get_setting('branding_notify')) + 1))
    else:
        set_setting('branding_notify', "1")
    if int(get_setting('branding_notify')) == 1:
        dlg.notification(addon_name + ' is provided by:', 'www.tvaddons.co', tvaddons_logo, 5000, False)
    elif int(get_setting('branding_notify')) == 9:
        set_setting('branding_notify', "0")

    # VPN Message
    if int(get_setting('vpn_notify')) != 1:
        dlg.ok(addon_name, "If you are outside the USA, you might want to consider subscribing to a VPN service in order to take full advantage of this addon. Sign up: [COLOR blue]www.tvaddons.co/vpn[/COLOR]")
        set_setting('vpn_notify', "1")

    add_dir("US TV", "", 1, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'ustv.png')))
    add_dir("UK TV", "", 2, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'uktv.png')))


def uktv():
    url = 'http://tvcatchup.com/'
    req = open_url(url)

    pattern = ""
    matches = find_multiple_matches(req, '<p class="channelsicon" style.+?>(.*?)</div>')

    for entry in matches:
        getchannel = find_single_match(entry, 'alt="Watch (.+?)"')
        gettitle = find_single_match(entry, '<br/> (.+?) </a>').replace("&#039;", "'")
        name = "{channel}-{title}".format(channel=getchannel, title=gettitle)
        url = "{url}{path}".format(url='http://tvcatchup.com', path=find_single_match(entry, '<a href="(.+?)"'))
        image = find_single_match(entry, 'src="https://www.tvcatchup.com/channel-images/(.+?)"')

        add_link(name, url, 3, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', image)))


def ustv():
    add_link("24/7 Retro", "", 4, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', '247Retro.png')))
    add_link("Aljazeera", "", 5, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'aljazeera-us.png')))
    add_link("Bloomberg", "", 6, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'bloomberg.png')))
    add_link("Buzzr", "", 7, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'buzzr.png')))
    add_link("CBS News", "", 8, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'cbsnews.png')))
    add_link("Charge!", "", 9, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'charge.png')))
    add_link("Cheddar", "", 10, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'cheddar.png')))
    add_link("Comet", "", 11, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'comet.png')))
    add_link("HSN", "", 12, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'hsn.png')))
    add_link("Light TV", "", 13, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'lighttv.png')))
    add_link("Newsmax TV", "", 14, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'newsmax.png')))
    add_link("Newsy", "", 15, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'newsy.png')))
    add_link("QVC", "", 16, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'qvc-us.png')))
    add_link("Rev'n TV", "", 17, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'revn.png')))
    add_link("RT News", "", 18, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'rt-us.png')))
    add_link("Sky News", "", 19, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skynews-us.png')))
    add_link("Stadium", "", 20, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'stadium.png')))
    add_link("TBD TV", "", 21, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'tbd.png')))
    add_link("The Country Network", "", 22, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'thecountrynetwork.png')))
    add_link("Tuff TV", "", 23, xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'tufftv.png')))

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()
url = None
name = None
mode = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

if mode is None:
    main()

elif mode == 1:
    ustv()

elif mode == 2:
    uktv()

elif mode == 3:
    TvCatchup().play(url)

elif mode == 4:
    TwentFourSevenRetro().play()

elif mode == 5:
    Aljazeera().play()

elif mode == 6:
    Bloomberg().play()

elif mode == 7:
    Buzzr().play()

elif mode == 8:
    CbsNews().play()

elif mode == 9:
    Charge().play()

elif mode == 10:
    Cheddar().play()

elif mode == 11:
    Comet().play()

elif mode == 12:
    Hsn().play()

elif mode == 13:
    LightTv().play()

elif mode == 14:
    NewsmaxTv().play()

elif mode == 15:
    Newsy().play()

elif mode == 16:
    Qvc().play()

elif mode == 17:
    RevnTv().play()

elif mode == 18:
    Rt().play()

elif mode == 19:
    SkyNews().play()

elif mode == 20:
    Stadium().play()

elif mode == 21:
    Tbd().play()

elif mode == 22:
    TheCountryNetwork().play()

elif mode == 23:
    TuffTv().play()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
