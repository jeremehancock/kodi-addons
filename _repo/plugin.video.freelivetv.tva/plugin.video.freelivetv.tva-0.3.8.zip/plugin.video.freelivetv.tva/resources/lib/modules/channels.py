"""
    Free Live TV Add-on
    Developed by mhancoc7

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from common import *
import json
import base64

import m7lib

stream_failed = "Unable to get stream. Please try again later."

class Channel():

    @staticmethod
    def play_247retro():
        try:
            stream = m7lib.Stream().twenty_four_seven_retro()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_aljazeera():
        try:
            stream = m7lib.Stream().aljazeera()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_bloomberg():
        try:
            stream = m7lib.Stream().bloomberg()
            if stream is not None:
                li = xbmcgui.ListItem(addon_name)
                xbmc.Player().play(stream, li, False)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_buzzr():
        try:
            stream = m7lib.Stream().buzzr()
            if stream is not None:
                li = xbmcgui.ListItem(addon_name)
                xbmc.Player().play(stream, li, False)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_catholic_tv():
        try:
            stream = m7lib.Stream().catholic_tv()
            if stream is not None:
                li = xbmcgui.ListItem(addon_name)
                xbmc.Player().play(stream, li, False)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_cbs_news():
        try:
            stream = m7lib.Stream().cbs_news()
            if stream is not None:
                li = xbmcgui.ListItem(addon_name)
                xbmc.Player().play(stream, li, False)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_charge():
        try:
            stream = m7lib.Stream().charge()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_cheddar():
        try:
            stream = m7lib.Stream().cheddar()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_comet():
        try:
            stream = m7lib.Stream().comet()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_hsn():
        try:
            stream = m7lib.Stream().hsn()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_light_tv():
        try:
            stream = m7lib.Stream().light_tv()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_newsmax_tv():
        try:
            stream = m7lib.Stream().newsmax_tv()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_pbs_kds():
        try:
            stream = m7lib.Stream().pbs_kids()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_qvc():
        try:
            stream = m7lib.Stream().qvc()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_revn_tv():
        try:
            stream = m7lib.Stream().revn_tv()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_rt():
        try:
            stream = m7lib.Stream().rt()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_sky_news():
        try:
            stream = m7lib.Stream().sky_news()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_stadium():
        try:
            stream = m7lib.Stream().stadium()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_tbd():
        try:
            stream = m7lib.Stream().tbd()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_the_country_network():
        try:
            stream = m7lib.Stream().the_country_network()
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

    @staticmethod
    def play_campfire(channel):
        try:
            stream = m7lib.Stream().campfire(channel)
            if stream is not None:
                play(stream)
            else:
                dlg.ok(addon_name, stream_failed)
        except:
            dlg.ok(addon_name, stream_failed)

