# plugin.video.animaltv

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/2082578ca66e4dd9ae6ffebf83975fde)](https://app.codacy.com/app/mhancoc7/plugin.video.animaltv?utm_source=github.com&utm_medium=referral&utm_content=mhancoc7/plugin.video.animaltv&utm_campaign=Badge_Grade_Settings)

## Submit issues via m7 Kodi Addons

[m7_kodi_addons](https://m7kodi.dev)
