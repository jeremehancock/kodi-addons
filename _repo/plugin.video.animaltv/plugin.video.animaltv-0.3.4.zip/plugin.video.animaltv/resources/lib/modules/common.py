"""
    Animal TV Add-on
    Developed by mhancoc7

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import sys
import xbmc
import xbmcgui
import xbmcaddon
import m7lib

dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(plugin_path, 'icon.png'))
fanart = xbmc.translatePath(os.path.join(plugin_path, 'icon.png'))


def stream_list():
    streams = m7lib.Stream.get_animal_tv_streams()
    for stream in sorted(streams, key=lambda k: k['title']):
        m7lib.Common.add_channel(stream["id"], stream["icon"], stream["fanart"], stream["title"])


def play_stream(video_id):
    stream_url = m7lib.Common.get_playable_youtube_url(video_id)
    m7lib.Common.play(stream_url)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param
