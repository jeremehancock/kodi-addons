# plugin.video.animaltv

## Submit issues via m7 Kodi Addons

[m7_kodi_addons](https://m7kodi.dev)

If you would like to help support my efforts please consider becoming a supporter at Patreon.

[![Patreon](./resources/images/patreon.jpg)](https://www.patreon.com/bozodev?fan_landing=true)
