# plugin.video.tubi.m7

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/8a9225cc580d453ea942d5d06ae62990)](https://app.codacy.com/app/mhancoc7/plugin.video.tubi.m7?utm_source=github.com&utm_medium=referral&utm_content=mhancoc7/plugin.video.tubi.m7&utm_campaign=Badge_Grade_Dashboard)

## Submit issues via m7 Kodi Addons

[m7_kodi_addons](https://m7kodi.dev)
