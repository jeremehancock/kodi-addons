'''
    HSN Live Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys,re,os,urllib,urllib2
from urllib2 import urlopen
import xbmc,xbmcgui,xbmcplugin,xbmcaddon

dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
addon_logo = xbmc.translatePath(os.path.join(plugin_path,'tvaddons_logo.png'))
hsn1_url = "https://hsn.com/watch/live"
hsn2_url = "https://hsn.com/watch/live?network=4"
stream_id_match_string = "watchTemplate.PlayLiveYoutubeVideo\('(.+?)'"
program_match_string = '<span class="show-title" id="show-title" tabindex="0">(.+?)</span>'

def find_single_match(text,pattern):
    result = ""
    try:    
        matches = re.findall(pattern,text,flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""
    return result

def get_playable_url(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url

if __name__ == '__main__':
    #TVADDONS Branding
    xbmcgui.Dialog().notification(addon_name + ' is provided by:','www.tvaddons.co',addon_logo,10000,False)

    #Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
    yt_addon = xbmcaddon.Addon('plugin.video.youtube')
    if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
        dlg.ok(addon_name, "This addon requires MPEG-DASH to be enabled in the YouTube addon. Once enabled try again.")
        yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
        xbmc.executebuiltin('yt_settings')
        xbmc.executebuiltin('Activatewindow(home)')
    else:
        #Get HSN TV current program info
        req = urllib2.Request(hsn1_url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        hsn1_program = find_single_match(link,program_match_string).replace("&amp;","&")

        #Get HSN2 TV current program info
        req = urllib2.Request(hsn2_url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        hsn2_program = find_single_match(link,program_match_string).replace("&amp;","&")
        
        #Channel Selection
        source = xbmcgui.Dialog().select("Choose Channel", ["[COLOR blue]HSN TV:[/COLOR] " + hsn1_program,"[COLOR blue]HSN2 TV:[/COLOR] " + hsn2_program])
        if source == 0:
            channel_url = hsn1_url
        if source == 1:
            channel_url = hsn2_url
        if source < 0:
            xbmc.executebuiltin('Activatewindow(home)')
            exit()

        #Get HSN TV or HSN2 TV stream depending on Channel Selection
        req = urllib2.Request(channel_url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        id = find_single_match(link,stream_id_match_string)
        if id is not "":
            stream = get_playable_url(id)
            xbmc.Player().play(stream)
            xbmc.executebuiltin('Activatewindow(home)')
        else:
            dlg.ok(addon_name, "Unable to get stream. Please try again later.")
            xbmc.executebuiltin('Activatewindow(home)')
